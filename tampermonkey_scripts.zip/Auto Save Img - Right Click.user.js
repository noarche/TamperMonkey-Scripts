// ==UserScript==
// @name         Auto Save Img - Right Click
// @namespace    https://github.com/noarche
// @version      1.0
// @description  Automatically save image when right-clicked
// @author       00001337
// @match        *://*/*
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    document.addEventListener('contextmenu', function(event) {
        let target = event.target;

        if (target.tagName === 'IMG') {
            event.preventDefault();

            let imageUrl = target.src;

            // Create an invisible anchor element
            let link = document.createElement('a');
            link.href = imageUrl;
            link.download = imageUrl.split('/').pop();
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
        }
    }, false);
})();
